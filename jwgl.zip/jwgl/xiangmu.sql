/*
Navicat MySQL Data Transfer

Source Server         : hmy
Source Server Version : 50605
Source Host           : localhost:3306
Source Database       : xiangmu

Target Server Type    : MYSQL
Target Server Version : 50605
File Encoding         : 65001

Date: 2019-12-01 19:51:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `class`
-- ----------------------------
DROP TABLE IF EXISTS `class`;
CREATE TABLE `class` (
  `classno` varchar(30) NOT NULL,
  `classname` varchar(30) NOT NULL,
  `pfno` varchar(30) NOT NULL,
  `depno` varchar(30) NOT NULL,
  PRIMARY KEY (`classno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of class
-- ----------------------------
INSERT INTO `class` VALUES ('c10', '2017-1班（网软）', 'p10', 'd10');
INSERT INTO `class` VALUES ('c11', '2017-2班（网软）', 'p10', 'd10');

-- ----------------------------
-- Table structure for `classroom`
-- ----------------------------
DROP TABLE IF EXISTS `classroom`;
CREATE TABLE `classroom` (
  `classroomno` varchar(30) NOT NULL,
  `clname` varchar(30) NOT NULL,
  PRIMARY KEY (`classroomno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of classroom
-- ----------------------------
INSERT INTO `classroom` VALUES ('b10', '  二教307');
INSERT INTO `classroom` VALUES ('b11', ' D404');
INSERT INTO `classroom` VALUES ('b12', 'B205');
INSERT INTO `classroom` VALUES ('b13', '二教306');
INSERT INTO `classroom` VALUES ('b14', 'D406');
INSERT INTO `classroom` VALUES ('b15', ' D306');
INSERT INTO `classroom` VALUES ('b16', '二教403');
INSERT INTO `classroom` VALUES ('b17', '二教415');
INSERT INTO `classroom` VALUES ('b18', 'D405');
INSERT INTO `classroom` VALUES ('b19', 'D206');
INSERT INTO `classroom` VALUES ('b40', '二教401');

-- ----------------------------
-- Table structure for `class_course`
-- ----------------------------
DROP TABLE IF EXISTS `class_course`;
CREATE TABLE `class_course` (
  `id` int(3) NOT NULL,
  `classno` varchar(30) NOT NULL,
  `termno` varchar(30) NOT NULL,
  `courseno` varchar(30) DEFAULT NULL,
  `classroomno` varchar(30) DEFAULT NULL,
  `time` varchar(30) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `flag` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of class_course
-- ----------------------------
INSERT INTO `class_course` VALUES ('1', 'c11', '5', 'co101', 'b10', '三56', '0', null);
INSERT INTO `class_course` VALUES ('2', 'c11', '5', 'co101', 'b40', '四56', '0', null);
INSERT INTO `class_course` VALUES ('3', 'c11', '5', 'co102', 'b11', '一12', '0', null);
INSERT INTO `class_course` VALUES ('4', 'c11', '5', 'co102', 'b16', '三12', '0', null);
INSERT INTO `class_course` VALUES ('5', 'c11', '5', 'co102', 'b16', '五12', '0', null);
INSERT INTO `class_course` VALUES ('6', 'c11', '5', 'co103', 'b14', '二12', '0', null);
INSERT INTO `class_course` VALUES ('7', 'c11', '5', 'co103', 'b18', '四12', '0', null);
INSERT INTO `class_course` VALUES ('8', 'c11', '5', 'co105', 'b13', '一56', '0', null);
INSERT INTO `class_course` VALUES ('9', 'c11', '5', 'co105', 'b13', '五34', '2', null);
INSERT INTO `class_course` VALUES ('10', 'c11', '5', 'co106', 'b13', '四34', '0', null);
INSERT INTO `class_course` VALUES ('11', 'c10', '5', 'co101', 'b10', '三56', '0', null);
INSERT INTO `class_course` VALUES ('12', 'c10', '5', 'co101', 'b40', '四56', '0', null);
INSERT INTO `class_course` VALUES ('13', 'c10', '5', 'co102', 'b11', '一12', '0', null);
INSERT INTO `class_course` VALUES ('14', 'c10', '5', 'co102', 'b16', '三12', '0', null);
INSERT INTO `class_course` VALUES ('15', 'c10', '5', 'co102', 'b16', '五12', '0', null);
INSERT INTO `class_course` VALUES ('16', 'c10', '5', 'co103', 'b14', '二12', '0', null);
INSERT INTO `class_course` VALUES ('17', 'c10', '5', 'co103', 'b18', '四12', '0', null);
INSERT INTO `class_course` VALUES ('18', 'c10', '5', 'co105', 'b13', '一56', '0', null);
INSERT INTO `class_course` VALUES ('19', 'c10', '5', 'co105', 'b13', '五34', '2', null);
INSERT INTO `class_course` VALUES ('20', 'c10', '5', 'co106', 'b13', '四34', '0', null);

-- ----------------------------
-- Table structure for `course`
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `courseno` varchar(30) NOT NULL,
  `cname` varchar(30) NOT NULL,
  `credit` float(2,1) NOT NULL,
  `tno` varchar(30) NOT NULL,
  `termno` varchar(30) NOT NULL,
  PRIMARY KEY (`courseno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES ('co101 ', 'javaweb', '3.5', 't1001', '5');
INSERT INTO `course` VALUES ('co102', 'MySQL', '5.0', 't1002', '5');
INSERT INTO `course` VALUES ('co103', '操作系统原理', '3.5', 't1004', '5');
INSERT INTO `course` VALUES ('co104', '线性代数', '3.0', 't1003', '5');
INSERT INTO `course` VALUES ('co105', '马克思原理', '2.5', 't1006', '5');
INSERT INTO `course` VALUES ('co106', '形势与政策', '2.0', 't1007', '5');
INSERT INTO `course` VALUES ('co107', '大数据', '3.0', 't1005', '5');

-- ----------------------------
-- Table structure for `department`
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department` (
  `depno` varchar(30) NOT NULL,
  `depname` varchar(30) NOT NULL,
  PRIMARY KEY (`depno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES ('d10', '信息工程学院');
INSERT INTO `department` VALUES ('d11', '工商管理学院');
INSERT INTO `department` VALUES ('d12', '旅游管理学院');
INSERT INTO `department` VALUES ('d13', '农学院');
INSERT INTO `department` VALUES ('d14', '林学院');
INSERT INTO `department` VALUES ('d15', '生物制药学院');
INSERT INTO `department` VALUES ('d16', '体育学院');
INSERT INTO `department` VALUES ('d17', '规划与设计学院');
INSERT INTO `department` VALUES ('d18', '食品学院');
INSERT INTO `department` VALUES ('d19', '酒店管理学院');
INSERT INTO `department` VALUES ('d20', '牧医工程学院');
INSERT INTO `department` VALUES ('d21', '园艺学院');
INSERT INTO `department` VALUES ('d22', '外国语学院');
INSERT INTO `department` VALUES ('d23', '水产学院');
INSERT INTO `department` VALUES ('d24', '茶学院');
INSERT INTO `department` VALUES ('d25', '财经学院');

-- ----------------------------
-- Table structure for `luntan`
-- ----------------------------
DROP TABLE IF EXISTS `luntan`;
CREATE TABLE `luntan` (
  `name` varchar(30) DEFAULT NULL,
  `title` text,
  `word` text,
  `time` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of luntan
-- ----------------------------
INSERT INTO `luntan` VALUES ('小姐妹', '1111', '111111', '2019/11/11');
INSERT INTO `luntan` VALUES ('222', '1123', '1111\r\n2222\r\n33333', '2019/11/23');

-- ----------------------------
-- Table structure for `manage`
-- ----------------------------
DROP TABLE IF EXISTS `manage`;
CREATE TABLE `manage` (
  `flag` varchar(2) NOT NULL,
  `ss` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of manage
-- ----------------------------
INSERT INTO `manage` VALUES ('1', '0');

-- ----------------------------
-- Table structure for `manager`
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager` (
  `mno` varchar(30) NOT NULL,
  `mpwd` varchar(30) NOT NULL,
  `kind` char(2) NOT NULL,
  PRIMARY KEY (`mno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of manager
-- ----------------------------
INSERT INTO `manager` VALUES ('hmy', '2019', '0');

-- ----------------------------
-- Table structure for `pj_jg`
-- ----------------------------
DROP TABLE IF EXISTS `pj_jg`;
CREATE TABLE `pj_jg` (
  `sno` varchar(30) NOT NULL,
  `tname` varchar(30) NOT NULL,
  `result` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`sno`,`tname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pj_jg
-- ----------------------------
INSERT INTO `pj_jg` VALUES ('1714154209', '侯丽萍', 'AAAAAAAAA');
INSERT INTO `pj_jg` VALUES ('1714154209', '朱艳平', 'AAABBBBCC');
INSERT INTO `pj_jg` VALUES ('1714154209', '胡平', 'AABBAABCD');
INSERT INTO `pj_jg` VALUES ('1714154209', '马原', 'AAAAAAAAA');
INSERT INTO `pj_jg` VALUES ('1714154221', '胡平', 'AAAAAAAAA');
INSERT INTO `pj_jg` VALUES ('1714154221', '马原', 'AAAAAAAAA');

-- ----------------------------
-- Table structure for `pj_question`
-- ----------------------------
DROP TABLE IF EXISTS `pj_question`;
CREATE TABLE `pj_question` (
  `id` int(5) NOT NULL,
  `question` text NOT NULL,
  `A` varchar(20) NOT NULL,
  `B` varchar(20) NOT NULL,
  `C` varchar(20) NOT NULL,
  `D` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pj_question
-- ----------------------------
INSERT INTO `pj_question` VALUES ('1', '老师讲课思维清晰，讲话清晰流利，逻辑清晰？', '非常满意', '满意', '不满意', '非常不满意');
INSERT INTO `pj_question` VALUES ('2', '对老师讲课效果是否满意', '非常满意', '满意', '不满意', '非常不满意');
INSERT INTO `pj_question` VALUES ('3', '老师的讲课速度', '非常满意', '满意', '不满意', '非常不满意');
INSERT INTO `pj_question` VALUES ('4', '老师上课的互动情况', '非常满意', '满意', '不满意', '非常不满意');
INSERT INTO `pj_question` VALUES ('5', '老师的PPT的情况', '非常满意', '满意', '不满意', '非常不满意');
INSERT INTO `pj_question` VALUES ('6', '对于老师的讲解', '非常满意', '满意', '不满意', '非常不满意');
INSERT INTO `pj_question` VALUES ('7', '对于老师上课的仪态', '非常满意', '满意', '不满意', '非常不满意');
INSERT INTO `pj_question` VALUES ('8', '老师的点到情况', '非常满意', '满意', '不满意', '非常不满意');
INSERT INTO `pj_question` VALUES ('9', '老师对于学生课下的提问', '非常满意', '满意', '不满意', '非常不满意');

-- ----------------------------
-- Table structure for `profession`
-- ----------------------------
DROP TABLE IF EXISTS `profession`;
CREATE TABLE `profession` (
  `pfno` varchar(30) NOT NULL,
  `pfname` varchar(30) NOT NULL,
  PRIMARY KEY (`pfno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of profession
-- ----------------------------
INSERT INTO `profession` VALUES ('p10', '网络工程（网络软件开发）');
INSERT INTO `profession` VALUES ('p11', '网络工程');

-- ----------------------------
-- Table structure for `score`
-- ----------------------------
DROP TABLE IF EXISTS `score`;
CREATE TABLE `score` (
  `stuno` varchar(30) NOT NULL,
  `courseno` varchar(30) NOT NULL,
  `termno` varchar(30) NOT NULL,
  `gcredit` float(2,1) DEFAULT NULL,
  `final` float(3,1) DEFAULT NULL,
  `flag` int(2) DEFAULT NULL,
  PRIMARY KEY (`stuno`,`courseno`,`termno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of score
-- ----------------------------
INSERT INTO `score` VALUES ('1714154201', 'co101', '5', '3.5', '80.0', null);
INSERT INTO `score` VALUES ('1714154201', 'co102', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154201', 'co103', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154201', 'co104', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154201', 'co105', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154201', 'co106', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154201', 'co107', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154209', 'co101', '5', '3.5', '88.0', null);
INSERT INTO `score` VALUES ('1714154209', 'co102', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154209', 'co103', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154209', 'co104', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154209', 'co105', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154209', 'co106', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154209', 'co107', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154218', 'co101', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154218', 'co102', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154218', 'co103', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154218', 'co104', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154218', 'co105', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154218', 'co106', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154218', 'co107', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154221', 'co101', '5', '3.5', '88.0', null);
INSERT INTO `score` VALUES ('1714154221', 'co102', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154221', 'co103', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154221', 'co104', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154221', 'co105', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154221', 'co106', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154221', 'co107', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154224', 'co101', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154224', 'co102', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154224', 'co103', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154224', 'co104', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154224', 'co105', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154224', 'co106', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154224', 'co107', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154232', 'co101', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154232', 'co102', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154232', 'co103', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154232', 'co104', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154232', 'co105', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154232', 'co106', '5', null, null, null);
INSERT INTO `score` VALUES ('1714154232', 'co107', '5', null, null, null);

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `stuno` varchar(30) NOT NULL,
  `sname` varchar(30) NOT NULL,
  `sex` char(2) NOT NULL,
  `classno` varchar(30) NOT NULL,
  `pwd` varchar(30) NOT NULL,
  `kind` char(2) NOT NULL,
  PRIMARY KEY (`stuno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('151415118', '王明召', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('16141541230', '刘秀芳', '女', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154101', '顾浩浩', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154102', '孙梦姣', '女', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154103', '徐文强', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154104', '谢浩', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154105', '禹林青', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154106', '韩威烨', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154107', '何俊楠', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154108', '牛玉', '女', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154109', '张亚龙', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154110', '王佳炜', '女', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154111', '李志浩', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154112', '李恒鑫', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154113', '孙瑞源', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154114', '韩敏杰', '女', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154115', '鲁文畅', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154116', '余杰', '女', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154117', '张小虎', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154118', '赵莹莹', '女', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154119', '匡杰', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154120', '姚春萌', '女', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154121', '张超', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154122', '李冰举', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154123', '苗宁', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154124', '刘飞飞', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154125', '张曼玉', '女', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154126', '刘龙飞', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154127', '钟靖波', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154128', '白海涛', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154129', '刘苗苗', '女', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154130', '赵金红', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154131', '马梦续', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154132', '贺晔', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154133', '周永波', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154134', '晁子涵', '女', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154135', '袁刚', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154136', '王燃燃', '女', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1714154201', '曹兵兵', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154202', '华东凯', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154203', '杨智鑫', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154204', '张垚垚', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154205', '王君', '女', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154206', '侯园园', '女', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154207', '宁凯', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154208', '王静阳', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154209', '胡梦雨', '女', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154210', '郭鑫源', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154211', '薛旭旭', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154212', '屈隆博', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154213', '陈冲', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154214', '崔宇飞', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154215', '黄赞', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154216', '南明辉', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154217', '周庆卓', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154218', '石慧杰', '女', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154219', '潘莹莹', '女', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154220', '张旭旭', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154221', '闫肖倩', '女', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154222', '魏怀建', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154223', '张潘辉', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154224', '吴冬春', '女', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154225', '高旭', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154226', '杨剑', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154227', '李芳勋', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154228', '张顺通', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154229', '楚明鑫', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154230', '王振州', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154231', '何雪莲', '女', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154232', '曲艺', '女', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154233', '杨帆', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154234', '汪文威', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1714154235', '周灵旭', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1722114133', '李文文', '女', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1722214105', '丁帅', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1722214111', '肖梦瑶', '女', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1723204106', '张永正', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1724044136', '吴国正', '男', 'c10', '123', '2');
INSERT INTO `student` VALUES ('1724174116', '单利盼', '女', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1725144109', '何玥澎', '男', 'c11', '123', '2');
INSERT INTO `student` VALUES ('1725184106', '任文斐', '男', 'c10', '123', '2');

-- ----------------------------
-- Table structure for `student_opcourse`
-- ----------------------------
DROP TABLE IF EXISTS `student_opcourse`;
CREATE TABLE `student_opcourse` (
  `id` int(3) NOT NULL,
  `stuno` varchar(30) NOT NULL,
  `termno` varchar(30) NOT NULL,
  `courseno` varchar(30) DEFAULT NULL,
  `classroomno` varchar(30) DEFAULT NULL,
  `opstatus` int(2) DEFAULT NULL,
  `time` varchar(30) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `flag` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student_opcourse
-- ----------------------------
INSERT INTO `student_opcourse` VALUES ('1', '1714154209', '5', 'co104', 'b15', '1', '二34', '0', '1');
INSERT INTO `student_opcourse` VALUES ('2', '1714154209', '5', 'co104', 'b19', '1', '五34', '1', '1');
INSERT INTO `student_opcourse` VALUES ('3', '1714154209', '5', 'co107', 'b12', '0', '一34', '0', '0');
INSERT INTO `student_opcourse` VALUES ('4', '1714154209', '5', 'co107', 'b17', '0', '三34', '1', '0');
INSERT INTO `student_opcourse` VALUES ('5', '1714154221', '5', 'co104', 'b15', '0', '二34', '0', '1');
INSERT INTO `student_opcourse` VALUES ('6', '1714154221', '5', 'co104', 'b19', '0', '五34', '1', '1');
INSERT INTO `student_opcourse` VALUES ('7', '1714154221', '5', 'co107', 'b12', '0', '一34', '0', '0');
INSERT INTO `student_opcourse` VALUES ('8', '1714154209', '5', 'co107', 'b17', '0', '三34', '1', '0');
INSERT INTO `student_opcourse` VALUES ('9', '1714154232', '5', 'co104', 'b15', '0', '二34', '0', '0');
INSERT INTO `student_opcourse` VALUES ('10', '1714154232', '5', 'co104', 'b19', '0', '五34', '1', '0');
INSERT INTO `student_opcourse` VALUES ('11', '1714154232', '5', 'co107', 'b12', '0', '一34', '0', '0');
INSERT INTO `student_opcourse` VALUES ('12', '1714154232', '5', 'co107', 'b17', '0', '三34', '1', '0');
INSERT INTO `student_opcourse` VALUES ('14', '1714154218', '5', 'co104', 'b15', '0', '二34', '0', '0');
INSERT INTO `student_opcourse` VALUES ('15', '1714154218', '5', 'co104', 'b19', '0', '五34', '1', '0');
INSERT INTO `student_opcourse` VALUES ('16', '1714154224', '5', 'co107', 'b12', '0', '一34', '0', '0');
INSERT INTO `student_opcourse` VALUES ('17', '1714154224', '5', 'co107', 'b17', '0', '三34', '1', '0');

-- ----------------------------
-- Table structure for `teacher`
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `tno` varchar(30) NOT NULL,
  `tname` varchar(30) NOT NULL,
  `depno` varchar(30) NOT NULL,
  `tpwd` varchar(30) NOT NULL,
  `kind` char(2) NOT NULL,
  PRIMARY KEY (`tno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES ('t1001', '侯丽萍', 'd10', '123', '1');
INSERT INTO `teacher` VALUES ('t1002', '朱艳平', 'd10', '123', '1');
INSERT INTO `teacher` VALUES ('t1003', '胡平', 'd10', '123', '1');
INSERT INTO `teacher` VALUES ('t1004', '马原', 'd10', '123', '1');
INSERT INTO `teacher` VALUES ('t1005', '李越颖', 'd10', '123', '1');
INSERT INTO `teacher` VALUES ('t1006', '宋东阳', 'd10', '123', '1');
INSERT INTO `teacher` VALUES ('t1007', '陈梦天', 'd10', '123', '1');

-- ----------------------------
-- Table structure for `term`
-- ----------------------------
DROP TABLE IF EXISTS `term`;
CREATE TABLE `term` (
  `termno` varchar(30) NOT NULL,
  `termname` varchar(30) NOT NULL,
  PRIMARY KEY (`termno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of term
-- ----------------------------
INSERT INTO `term` VALUES ('1', '第一学期');
INSERT INTO `term` VALUES ('2', '第二学期');
INSERT INTO `term` VALUES ('3', '第三学期');
INSERT INTO `term` VALUES ('4', '第四学期');
INSERT INTO `term` VALUES ('5', '第五学期');
INSERT INTO `term` VALUES ('6', '第六学期');
INSERT INTO `term` VALUES ('7', '第七学期');
INSERT INTO `term` VALUES ('8', '第八学期');
